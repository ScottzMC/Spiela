/*Summernote Init*/

$(function() {
	"use strict";
	$('.summernote').summernote({
		height: 300,
	});
});