<?php

	$clientid	=	'670824505166-sp88co7o8043u1ai10ut5831q6408kh4.apps.googleusercontent.com';
	$clientsecret	=	'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';
	$redirecturi	=	'https://server.com/ccc/demo/result.php'; //Add your redirect URl	
	$maxresults	=	 50;
?>